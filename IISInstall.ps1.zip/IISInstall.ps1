Configuration InstallIIS
# Configuration Main
{

Param ( [string] $nodeName, $WebDeployPackagePath, [string] $certStoreName, [string]  $certDomain )

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
    WindowsFeature WebServerRole
    {
      Name = "Web-Server"
      Ensure = "Present"
    }
    WindowsFeature WebManagementConsole
    {
      Name = "Web-Mgmt-Console"
      Ensure = "Present"
    }
    WindowsFeature WebManagementService
    {
      Name = "Web-Mgmt-Service"
      Ensure = "Present"
    }
    WindowsFeature ASPNet45
    {
      Name = "Web-Asp-Net45"
      Ensure = "Present"
    }
    WindowsFeature HTTPRedirection
    {
      Name = "Web-Http-Redirect"
      Ensure = "Present"
    }
    WindowsFeature CustomLogging
    {
      Name = "Web-Custom-Logging"
      Ensure = "Present"
    }
    WindowsFeature LogginTools
    {
      Name = "Web-Log-Libraries"
      Ensure = "Present"
    }
    WindowsFeature RequestMonitor
    {
      Name = "Web-Request-Monitor"
      Ensure = "Present"
    }
    WindowsFeature Tracing
    {
      Name = "Web-Http-Tracing"
      Ensure = "Present"
    }
    WindowsFeature BasicAuthentication
    {
      Name = "Web-Basic-Auth"
      Ensure = "Present"
    }
    WindowsFeature WindowsAuthentication
    {
      Name = "Web-Windows-Auth"
      Ensure = "Present"
    }
    WindowsFeature ApplicationInitialization
    {
      Name = "Web-AppInit"
      Ensure = "Present"
    }
    Script DownloadWebDeploy
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
        }
        SetScript ={
            $source = "https://download.microsoft.com/download/0/1/D/01DC28EA-638C-4A22-A57B-4CEF97755C6C/WebDeploy_amd64_en-US.msi"
            $dest = "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
            Invoke-WebRequest $source -OutFile $dest
        }
        GetScript = {@{Result = "DownloadWebDeploy"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
    Package InstallWebDeploy
    {
        Ensure = "Present"  
        Path  = "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
        Name = "Microsoft Web Deploy 3.6"
        ProductId = "{6773A61D-755B-4F74-95CC-97920E45E696}"
        Arguments = "ADDLOCAL=ALL"
        DependsOn = "[Script]DownloadWebDeploy"
    }
    Service StartWebDeploy
    {                    
        Name = "WMSVC"
        StartupType = "Automatic"
        State = "Running"
        DependsOn = "[Package]InstallWebDeploy"
    }
	Script DeployWebPackage
	{
		GetScript = {@{Result = "DeployWebPackage"}}
		
        TestScript = {
            $false
        }
		
        SetScript = {
			$WebClient = New-Object -TypeName System.Net.WebClient
			$Destination = "C:\WindowsAzure\WebApplication.zip" 
			$WebClient.DownloadFile($using:WebDeployPackagePath,$destination)
			$Argument = '-source:package="C:\WindowsAzure\WebApplication.zip" -dest:auto,ComputerName="localhost", -verb:sync -allowUntrusted'
			$MSDeployPath = (Get-ChildItem "HKLM:\SOFTWARE\Microsoft\IIS Extensions\MSDeploy" | Select -Last 1).GetValue("InstallPath")
			Start-Process "$MSDeployPath\msdeploy.exe" $Argument -Verb runas 
			
			## create 443 binding from the cert store
			if ( -not ($null -ne (get-webbinding | where-object {$_.bindinginformation -eq "*:443:"}))) {
				$certPath = 'cert:\LocalMachine\' + $using:certStoreName				
				$certObj = Get-ChildItem -Path $certPath -DNSName $using:certDomain
				New-WebBinding -Name "Default Web Site" -IPAddress "*" -Port 443 -Protocol https					
				$certWThumb = $certPath + '\' + $certObj.Thumbprint 
				cd IIS:\SSLBindings
				get-item $certWThumb | new-item 0.0.0.0!443
			}
		}
	}
    Script DownloadUrlRewrite
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\rewrite_amd64.msi"
        }
        SetScript ={
            $source = "http://go.microsoft.com/fwlink/?LinkID=615137"
            $dest = "C:\WindowsAzure\rewrite_amd64.msi"
            Invoke-WebRequest $source -OutFile $dest
        }
        GetScript = {@{Result = "DownloadUrlRewrite"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
	Package InstallUrlRewrite
	{
		#Install URL Rewrite module for IIS
		DependsOn = "[Script]DownloadUrlRewrite"
		Ensure = "Present"
		Name = "IIS URL Rewrite Module 2"
		Path = "C:\WindowsAzure\rewrite_amd64.msi"
		Arguments = "/quiet"
		ProductId = "{08F0318A-D113-4CF0-993E-50F191D397AD}"
	}
	Script DownloadStartupBatch
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\startup.bat"
        }
        SetScript ={
            $source = "https://tmc2staging.blob.core.windows.net/deploy/DSC/startup.bat?sv=2016-05-31&ss=bfqt&srt=sco&sp=rwdlacup&se=2019-04-01T18:28:10Z&st=2017-06-01T10:28:10Z&spr=https&sig=CsVArj2oxoGmg1jqd6MM1GQyS10hJA0b3wLMBdXMphg%3D"
            $dest = "C:\WindowsAzure\startup.bat"
            Invoke-WebRequest $source -OutFile $dest 
			start-process $dest 
        }
        GetScript = {@{Result = "DownloadStartupBatch"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
	Script DownloadSecurityApp
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\SecurityStartupApp.exe"
        }
        SetScript ={
            $source = "https://tmc2staging.blob.core.windows.net/deploy/DSC/SecurityStartupApp.exe?sv=2016-05-31&ss=bfqt&srt=sco&sp=rwdlacup&se=2019-04-01T18:28:10Z&st=2017-06-01T10:28:10Z&spr=https&sig=CsVArj2oxoGmg1jqd6MM1GQyS10hJA0b3wLMBdXMphg%3D"
            $dest = "C:\WindowsAzure\SecurityStartupApp.exe"
            Invoke-WebRequest $source -OutFile $dest 
        }
        GetScript = {@{Result = "DownloadSecurityApp"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
	Script DownloadSecurityBatch
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\securitystartup.bat"
        }
        SetScript ={
            $source = "https://tmc2staging.blob.core.windows.net/deploy/DSC/securitystartup.bat?sv=2016-05-31&ss=bfqt&srt=sco&sp=rwdlacup&se=2019-04-01T18:28:10Z&st=2017-06-01T10:28:10Z&spr=https&sig=CsVArj2oxoGmg1jqd6MM1GQyS10hJA0b3wLMBdXMphg%3D"
            $dest = "C:\WindowsAzure\securitystartup.bat"
            Invoke-WebRequest $source -OutFile $dest 
			start-process $dest 
        }
        GetScript = {@{Result = "DownloadSecurityBatch"}}
        DependsOn = "[Script]DownloadSecurityApp"
    }
	Script DownloadDisableSSLv3
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\DisableSslv3.ps1"
        }
        SetScript ={
            $source = "https://tmc2staging.blob.core.windows.net/deploy/DSC/DisableSslv3.ps1?sv=2016-05-31&ss=bfqt&srt=sco&sp=rwdlacup&se=2019-04-01T18:28:10Z&st=2017-06-01T10:28:10Z&spr=https&sig=CsVArj2oxoGmg1jqd6MM1GQyS10hJA0b3wLMBdXMphg%3D"
            $dest = "C:\WindowsAzure\DisableSslv3.ps1"
            Invoke-WebRequest $source -OutFile $dest 
			Start-Process powershell "-ExecutionPolicy Bypass -NoProfile -Command $dest" -Verb RunAs
        }
        GetScript = {@{Result = "DownloadDisableSSLv3"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
	Script DownloadIISPoolScript
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\IISPool.ps1"
        }
        SetScript ={
            $source = "https://tmc2staging.blob.core.windows.net/deploy/DSC/IISPool.ps1?sv=2016-05-31&ss=bfqt&srt=sco&sp=rwdlacup&se=2019-04-01T18:28:10Z&st=2017-06-01T10:28:10Z&spr=https&sig=CsVArj2oxoGmg1jqd6MM1GQyS10hJA0b3wLMBdXMphg%3D"
            $dest = "C:\WindowsAzure\IISPool.ps1"
            Invoke-WebRequest $source -OutFile $dest 
			$username = 'atriis'
            $password = '1q2w3e4r5T'
            $securePassword = ConvertTo-SecureString $password -AsPlainText -Force
            $credential = New-Object System.Management.Automation.PSCredential $username, $securePassword
			Start-Process powershell "-ExecutionPolicy Bypass -NoProfile -Command $dest -Credential $credential" -Verb RunAs
        }
        GetScript = {@{Result = "DownloadIISPoolScript"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
	Script DownloadStartSiteBatch
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\startupsite.bat"
        }
        SetScript ={
            $source = "https://tmc2staging.blob.core.windows.net/deploy/DSC/startupsite.bat?sv=2016-05-31&ss=bfqt&srt=sco&sp=rwdlacup&se=2019-04-01T18:28:10Z&st=2017-06-01T10:28:10Z&spr=https&sig=CsVArj2oxoGmg1jqd6MM1GQyS10hJA0b3wLMBdXMphg%3D"
            $dest = "C:\WindowsAzure\startupsite.bat"
            Invoke-WebRequest $source -OutFile $dest 
			start-process $dest 
        }
        GetScript = {@{Result = "DownloadStartSiteBatch"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
  }
}